﻿using Newtonsoft.Json;
using Practicle_Assignment_Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace Practicle_Assignment_Web.Controllers
{
    public class AssigmentController : Controller
    {
        // GET: Assigment
        string Baseurl = "http://localhost:52721/";
        public async Task<ActionResult> Index()
        {
            List<User> user = new List<User>();
            using (var client = new HttpClient())
            {
                //Passing service base url
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                //Define request data format
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage Res = await client.GetAsync("api/Assignment");
                //Checking the response is successful or not which is sent using HttpClient
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api
                    var response = Res.Content.ReadAsStringAsync().Result;
                    //Deserializing the response recieved from web api and storing into the user list
                    user = JsonConvert.DeserializeObject<List<User>>(response);
                }

                return View(user);

            }
        }
        
    }
}

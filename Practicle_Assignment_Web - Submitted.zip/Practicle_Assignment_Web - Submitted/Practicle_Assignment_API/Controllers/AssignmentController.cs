﻿using Practicle_Assignment_API.DAL;
using Practicle_Assignment_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Practicle_Assignment_API.Controllers
{
    public class AssignmentController : ApiController
    {
        // GET: api/Assignment
        UserRepo userrepo = new UserRepo();
        public IEnumerable<User> Get()
        {
            return userrepo.GetUsers();
        }
        
        // GET: api/Assignment/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Assignment
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Assignment/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Assignment/5
        public void Delete(int id)
        {
        }
    }
}

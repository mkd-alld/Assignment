﻿using Practicle_Assignment_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Practicle_Assignment_API.DAL
{
    public class UserRepo
    {
        Practicle_AssignmentEntities dbContext = new Practicle_AssignmentEntities();
        public List<Models.User> GetUsers()
        {
            return dbContext.Users.ToList<User>();
           

        }
        
    }
}